const https = require('https');
const fs = require('fs');
const path = require('path');

const crops = [
    {
        name: 'rice',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'maize',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'wheat',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'potatoes',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'sugarcane',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'cotton',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'soybean',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    },
    {
        name: 'groundnut',
        url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    }
];

// Ensure the crops directory exists
const cropsDir = path.join(__dirname, 'images', 'crops');
if (!fs.existsSync(cropsDir)) {
    fs.mkdirSync(cropsDir, { recursive: true });
}

// Download each image
crops.forEach(crop => {
    const filePath = path.join(cropsDir, `${crop.name}.jpg`);
    
    https.get(crop.url, (response) => {
        const file = fs.createWriteStream(filePath);
        response.pipe(file);
        
        file.on('finish', () => {
            file.close();
            console.log(`Downloaded ${crop.name}.jpg`);
        });
    }).on('error', (err) => {
        console.error(`Error downloading ${crop.name}.jpg:`, err.message);
    });
}); 