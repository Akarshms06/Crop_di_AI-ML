// Get disease details from localStorage
function getDiseaseDetails() {
    const diseaseData = localStorage.getItem('selectedDisease');
    if (!diseaseData) {
        window.location.href = 'knowledge.html';
        return null;
    }
    return JSON.parse(diseaseData);
}

// Create disease details HTML
function createDiseaseDetails(disease) {
    return `
        <div class="disease-header">
            <img src="${disease.image}" alt="${disease.name}" class="disease-image">
            <div class="disease-info">
                <h1>${disease.name}</h1>
                <div class="disease-tags">
                    <span class="disease-tag">${disease.crop}</span>
                </div>
            </div>
        </div>

        <div class="info-section">
            <h3>Symptoms</h3>
            <ul>
                ${disease.symptoms.map(symptom => `<li>${symptom}</li>`).join('')}
            </ul>
        </div>

        <div class="info-section">
            <h3>Causes</h3>
            <ul>
                ${disease.causes.map(cause => `<li>${cause}</li>`).join('')}
            </ul>
        </div>

        <div class="info-section">
            <h3>Treatment Options</h3>
            <div class="treatment-grid">
                <div class="treatment-card">
                    <h4>Organic Solutions</h4>
                    <ul>
                        ${disease.treatments.organic.map(treatment => `<li>${treatment}</li>`).join('')}
                    </ul>
                </div>
                <div class="treatment-card chemical">
                    <h4>Chemical Solutions</h4>
                    <ul>
                        ${disease.treatments.chemical.map(treatment => `<li>${treatment}</li>`).join('')}
                    </ul>
                </div>
            </div>
        </div>

        <div class="info-section">
            <h3>Prevention Tips</h3>
            <ul>
                ${disease.prevention.map(tip => `<li>${tip}</li>`).join('')}
            </ul>
        </div>

        <div class="action-buttons">
            <button class="action-btn" onclick="markAsTreated()">
                <i class="fas fa-check"></i>
                Mark As Treated
            </button>
            <button class="action-btn secondary" onclick="window.location.href='knowledge.html'">
                <i class="fas fa-book"></i>
                Back to Knowledge Base
            </button>
        </div>
    `;
}

// Mark disease as treated
function markAsTreated() {
    const disease = getDiseaseDetails();
    if (disease) {
        // Get existing treated diseases or create new array
        const treatedDiseases = JSON.parse(localStorage.getItem('treatedDiseases') || '[]');
        
        // Add current disease with timestamp
        treatedDiseases.push({
            ...disease,
            treatedDate: new Date().toISOString()
        });
        
        // Save back to localStorage
        localStorage.setItem('treatedDiseases', JSON.stringify(treatedDiseases));
        
        // Show success message
        alert('Disease marked as treated! You can view your treatment history in the dashboard.');
        
        // Redirect to home page
        window.location.href = 'index.html';
    }
}

// Initialize the page
function init() {
    const disease = getDiseaseDetails();
    if (disease) {
        document.getElementById('diseaseDetails').innerHTML = createDiseaseDetails(disease);
    }
}

// Run initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', init); 