const TRANSLATION_API_KEY = '21979715-15b6-4912-8d94-299bff26d7f0';
const TRANSLATION_API_URL = 'https://api.sarvam.ai/translate';

class TranslationService {
    constructor() {
        this.currentLanguage = 'en-IN';
        this.translatableElements = new Set();
    }

    async translateText(text, targetLanguage) {
        try {
            const response = await fetch(TRANSLATION_API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-subscription-key': TRANSLATION_API_KEY
                },
                body: JSON.stringify({
                    input: text,
                    source_language_code: 'auto',
                    target_language_code: targetLanguage,
                    mode: 'formal',
                    enable_preprocessing: true
                })
            });

            if (!response.ok) {
                throw new Error('Translation failed');
            }

            const data = await response.json();
            return data.translated_text;
        } catch (error) {
            console.error('Translation error:', error);
            return text; // Return original text if translation fails
        }
    }

    async translatePage(targetLanguage) {
        if (this.currentLanguage === targetLanguage) return;

        const elements = document.querySelectorAll('[data-translate]');
        const translations = await Promise.all(
            Array.from(elements).map(async element => {
                const originalText = element.getAttribute('data-original-text') || element.textContent;
                element.setAttribute('data-original-text', originalText);
                return {
                    element,
                    translatedText: await this.translateText(originalText, targetLanguage)
                };
            })
        );

        translations.forEach(({ element, translatedText }) => {
            element.textContent = translatedText;
        });

        this.currentLanguage = targetLanguage;
    }

    addTranslatableElement(element) {
        this.translatableElements.add(element);
    }
}

// Create a global instance
window.translationService = new TranslationService(); 