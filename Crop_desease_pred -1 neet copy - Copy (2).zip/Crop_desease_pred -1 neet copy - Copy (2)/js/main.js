// Daily farming tips
const farmingTips = [
    "Regular monitoring of crop health can prevent major disease outbreaks.",
    "Water your plants early in the morning for best results.",
    "Rotate your crops to maintain soil health and prevent disease buildup.",
    "Use organic compost to improve soil fertility naturally.",
    "Keep a record of weather patterns to better predict disease risks.",
    "Prune affected leaves immediately to prevent disease spread.",
    "Maintain proper spacing between plants for good air circulation.",
    "Test your soil regularly to ensure proper nutrient balance."
];

// Update daily tip
function updateDailyTip() {
    const tipElement = document.getElementById('daily-tip-text');
    if (tipElement) {
        const randomTip = farmingTips[Math.floor(Math.random() * farmingTips.length)];
        tipElement.textContent = randomTip;
    }
}

// Update greeting based on time of day
function updateGreeting() {
    const greetingElement = document.getElementById('greeting');
    if (!greetingElement) return;

    const hour = new Date().getHours();
    let greeting = '';

    if (hour >= 5 && hour < 12) {
        greeting = 'Good Morning';
    } else if (hour >= 12 && hour < 17) {
        greeting = 'Good Afternoon';
    } else if (hour >= 17 && hour < 21) {
        greeting = 'Good Evening';
    } else {
        greeting = 'Good Night';
    }

    greetingElement.textContent = `${greeting}, Farmer!`;
    greetingElement.setAttribute('data-translate', `${greeting}, Farmer!`);
}

// Add animation classes to elements
function addAnimationClasses() {
    const elements = document.querySelectorAll('.action-card, .status-card, .tip-card');
    elements.forEach((element, index) => {
        element.classList.add('fade-in');
        element.style.animationDelay = `${index * 0.1}s`;
    });
}

// --- Dashboard Weather Panel Logic ---
const DASHBOARD_API_KEY = '8d997f0f9d22631466275eb328df18a8';

async function fetchDashboardWeather(location) {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${DASHBOARD_API_KEY}`);
        const data = await response.json();
        return {
            location: data.name,
            temperature: Math.round(data.main.temp),
            description: data.weather[0].description,
            icon: data.weather[0].icon
        };
    } catch (error) {
        return null;
    }
}

function updateDashboardWeatherPanel(weather) {
    const loc = document.getElementById('dashboardLocation');
    const weatherSpan = document.getElementById('dashboardWeather');
    if (weather && loc && weatherSpan) {
        loc.textContent = weather.location;
        weatherSpan.innerHTML = `<img src='https://openweathermap.org/img/wn/${weather.icon}.png' alt='' style='vertical-align:middle;width:32px;height:32px;margin-right:8px;'>${weather.temperature}°C, ${weather.description}`;
    } else if (loc && weatherSpan) {
        loc.textContent = 'Unavailable';
        weatherSpan.textContent = 'Weather unavailable';
    }
}

function getDashboardLocationAndWeather() {
    // Check if a location was searched in environment page
    const storedLocation = localStorage.getItem('environmentLocation');
    if (storedLocation) {
        fetchDashboardWeather(storedLocation).then(updateDashboardWeatherPanel);
        return;
    }
    // Try geolocation, fallback to Bangalore
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (pos) => {
            const lat = pos.coords.latitude;
            const lon = pos.coords.longitude;
            try {
                const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${DASHBOARD_API_KEY}`);
                const data = await response.json();
                updateDashboardWeatherPanel({
                    location: data.name,
                    temperature: Math.round(data.main.temp),
                    description: data.weather[0].description,
                    icon: data.weather[0].icon
                });
            } catch {
                fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
            }
        }, () => {
            fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
        });
    } else {
        fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
    }
}

// --- End Dashboard Weather Panel Logic ---

// Initialize the application
function init() {
    updateDailyTip();
    updateGreeting();
    addAnimationClasses();
    getDashboardLocationAndWeather();
    
    // Update tip every 30 seconds
    setInterval(updateDailyTip, 30000);
    
    // Update greeting every minute
    setInterval(updateGreeting, 60000);
}

// Run initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Add smooth scrolling to all links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Add click effect to action cards
document.querySelectorAll('.action-card').forEach(card => {
    card.addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 200);
    });
}); 