// Mock disease data for simulation
const mockDiseases = [
    {
        name: "Leaf Rust",
        confidence: 85,
        organicSolutions: [
            "Remove and destroy infected leaves",
            "Apply neem oil spray every 7-10 days",
            "Improve air circulation around plants"
        ],
        chemicalSolutions: [
            "Apply fungicide containing chlorothalonil",
            "Follow manufacturer's instructions for application",
            "Wear protective gear during application"
        ]
    },
    {
        name: "Powdery Mildew",
        confidence: 75,
        organicSolutions: [
            "Spray with baking soda solution",
            "Remove affected plant parts",
            "Ensure proper spacing between plants"
        ],
        chemicalSolutions: [
            "Apply sulfur-based fungicide",
            "Use potassium bicarbonate spray",
            "Follow safety guidelines for application"
        ]
    },
    {
        name: "Bacterial Blight",
        confidence: 90,
        organicSolutions: [
            "Remove infected plants immediately",
            "Use copper-based sprays",
            "Practice crop rotation"
        ],
        chemicalSolutions: [
            "Apply copper-based bactericides",
            "Use streptomycin sulfate",
            "Follow strict application schedule"
        ]
    }
];

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const imagePreview = document.getElementById('imagePreview');
const analyzeBtn = document.getElementById('analyzeBtn');
const loading = document.getElementById('loading');
const resultContainer = document.getElementById('resultContainer');
const diseaseName = document.getElementById('diseaseName');
const confidenceFill = document.getElementById('confidenceFill');
const confidenceText = document.getElementById('confidenceText');

// Handle drag and drop events
uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = 'rgba(76, 175, 80, 0.1)';
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.backgroundColor = '';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = '';
    const file = e.dataTransfer.files[0];
    handleFile(file);
});

// Handle file input change
fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    handleFile(file);
});

// Handle file selection
function handleFile(file) {
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block';
            analyzeBtn.disabled = false;
        };
        reader.readAsDataURL(file);
    }
}

// Replace simulateAnalysis function with real API call
async function analyzeImage() {
    loading.style.display = 'block';
    resultContainer.style.display = 'none';
    analyzeBtn.disabled = true;

    try {
        // 1. Upload image to imgbb
        const imgbbApiKey = '318c126906609b8f2b8e7046550a0a83';
        const base64Image = imagePreview.src.split(',')[1];
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbApiKey}`, {
            method: 'POST',
            body: new URLSearchParams({
                image: base64Image
            })
        });
        const imgbbData = await imgbbResponse.json();
        if (!imgbbData.success) throw new Error('Image upload failed');
        const imageUrl = imgbbData.data.url;

        // 2. Send public image URL to OpenRouter (Gemini model)
        const contentArr = [
            {
                "type": "text",
                "text": "Analyze this crop image and identify any diseases. Provide the disease name, confidence level, and treatment recommendations in both organic and chemical methods. Format the response as JSON with the following structure: { disease: string, confidence: number, organicSolutions: string[], chemicalSolutions: string[] }"
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": imageUrl
                }
            }
        ];
        const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": "Bearer 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",
                "HTTP-Referer": window.location.origin,
                "X-Title": "Crop Doctor",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "model": "google/gemini-2.0-flash-exp:free",
                "messages": [
                    {
                        "role": "user",
                        "content": contentArr
                    }
                ]
            })
        });

        const data = await response.json();
        console.log('OpenRouter response:', JSON.stringify(data, null, 2));

        let analysis = null;
        if (data.choices && data.choices[0]?.message?.content) {
            try {
                let content = data.choices[0].message.content.trim();
                // Remove code block markers if present
                if (content.startsWith('```json')) {
                    content = content.replace(/^```json/, '').replace(/```$/, '').trim();
                } else if (content.startsWith('```')) {
                    content = content.replace(/^```/, '').replace(/```$/, '').trim();
                }
                analysis = JSON.parse(content);
            } catch (e) {
                throw new Error('AI response could not be parsed as JSON.\n' + data.choices[0].message.content);
            }
        } else if (data.error && data.error.message) {
            throw new Error(data.error.message);
        } else {
            throw new Error('Unexpected API response: ' + JSON.stringify(data, null, 2));
        }

        // Update results (detailed)
        diseaseName.textContent = analysis.disease || 'Unknown';
        confidenceText.textContent = analysis.confidence ? `${analysis.confidence * 100}%` : 'N/A';
        setTimeout(() => {
            confidenceFill.style.width = analysis.confidence ? `${analysis.confidence * 100}%` : '0%';
        }, 100);

        // Detailed fields
        const organicList = document.querySelector('.organic ul');
        const chemicalList = document.querySelector('.chemical ul');
        const symptomsSection = document.createElement('div');
        const causesSection = document.createElement('div');

        // Symptoms
        symptomsSection.innerHTML = analysis.symptoms && Array.isArray(analysis.symptoms)
            ? `<h4>Symptoms</h4><ul>${analysis.symptoms.map(s => `<li>${s}</li>`).join('')}</ul>`
            : '';
        // Causes
        causesSection.innerHTML = analysis.causes && Array.isArray(analysis.causes)
            ? `<h4>Causes</h4><ul>${analysis.causes.map(c => `<li>${c}</li>`).join('')}</ul>`
            : '';

        // Insert symptoms and causes above the treatment advice
        const diseaseInfo = resultContainer.querySelector('.disease-info');
        // Remove previous if any
        const oldSymptoms = resultContainer.querySelector('.ai-symptoms');
        const oldCauses = resultContainer.querySelector('.ai-causes');
        if (oldSymptoms) oldSymptoms.remove();
        if (oldCauses) oldCauses.remove();
        if (symptomsSection.innerHTML) {
            symptomsSection.className = 'ai-symptoms';
            diseaseInfo.appendChild(symptomsSection);
        }
        if (causesSection.innerHTML) {
            causesSection.className = 'ai-causes';
            diseaseInfo.appendChild(causesSection);
        }

        organicList.innerHTML = Array.isArray(analysis.organicSolutions)
            ? analysis.organicSolutions.map(solution => `<li>${solution}</li>`).join('')
            : '<li>No data</li>';
        chemicalList.innerHTML = Array.isArray(analysis.chemicalSolutions)
            ? analysis.chemicalSolutions.map(solution => `<li>${solution}</li>`).join('')
            : '<li>No data</li>';

        localStorage.setItem('lastAnalysis', JSON.stringify({
            disease: analysis.disease,
            confidence: analysis.confidence,
            timestamp: new Date().toISOString()
        }));

    } catch (error) {
        console.error('Error analyzing image:', error);
        alert('Error analyzing image. ' + error.message);
    } finally {
        loading.style.display = 'none';
        resultContainer.style.display = 'block';
        analyzeBtn.disabled = false;
    }
}

// Update event listener to use new analyzeImage function
analyzeBtn.addEventListener('click', analyzeImage);

// Add click event to upload area
uploadArea.addEventListener('click', () => {
    fileInput.click();
}); 