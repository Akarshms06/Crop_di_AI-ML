// Market data configuration
const OPENROUTER_API_KEY = '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';
let marketData = [];
let historicalData = new Map(); // Store historical data for each crop

// Indian states for filtering
const indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
    'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
    'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
];

// Fetch real-time market data from OpenRouter API
async function fetchMarketData() {
    try {
        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
                'HTTP-Referer': 'https://cropdoctor.com',
                'X-Title': 'CropDoctor',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model: 'deepseek/deepseek-r1:free',
                messages: [{
                    role: 'system',
                    content: 'You are an expert in Indian agricultural markets. Provide accurate, current market prices and trends for major crops across different states in India. Include real-time price changes, market volumes, and demand indicators.'
                },
                {
                    role: 'user',
                    content: `Please provide current market prices for major agricultural commodities in India. For each crop, include:
                    1. Crop name and variety
                    2. State and major market
                    3. Current price per quintal
                    4. Price change percentage from last hour
                    5. Price change percentage from last day
                    6. Price change percentage from last week
                    7. Growing season
                    8. Quality grade
                    9. Price range (min-max)
                    10. Market volume
                    11. Demand status
                    12. Trading volume
                    13. Market sentiment
                    
                    Format the response as a JSON array with objects containing these fields:
                    {
                        "crop": "string",
                        "variety": "string",
                        "state": "string",
                        "price": number,
                        "unit": "string",
                        "change": {
                            "hour": number,
                            "day": number,
                            "week": number
                        },
                        "market": "string",
                        "season": "string",
                        "quality": "string",
                        "minPrice": number,
                        "maxPrice": number,
                        "volume": "string",
                        "demand": "string",
                        "tradingVolume": number,
                        "sentiment": "string",
                        "lastUpdated": "ISO date string"
                    }
                    
                    Ensure the data is realistic and current for Indian markets.`
                }],
            }),
        });

        if (!response.ok) {
            throw new Error('Failed to fetch market data');
        }

        const data = await response.json();
        try {
            const marketInfo = JSON.parse(data.choices[0].message.content);
            if (Array.isArray(marketInfo) && marketInfo.length > 0) {
                // Update historical data
                updateHistoricalData(marketInfo);
                return marketInfo;
            }
            throw new Error('Invalid data format received');
        } catch (parseError) {
            console.error('Error parsing market data:', parseError);
            return getLocalMarketData();
        }
    } catch (error) {
        console.error('Error fetching market data:', error);
        return getLocalMarketData();
    }
}

// Update historical data for price trends
function updateHistoricalData(newData) {
    const now = new Date();
    newData.forEach(item => {
        if (!historicalData.has(item.crop)) {
            historicalData.set(item.crop, []);
        }
        
        const cropHistory = historicalData.get(item.crop);
        cropHistory.push({
            price: item.price,
            timestamp: now,
            change: item.change
        });
        
        // Keep only last 24 hours of data
        const oneDayAgo = new Date(now - 24 * 60 * 60 * 1000);
        const filteredHistory = cropHistory.filter(entry => entry.timestamp > oneDayAgo);
        historicalData.set(item.crop, filteredHistory);
    });
}

// Create price chart with real historical data
function createPriceChart(canvasId, crop) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    const history = historicalData.get(crop) || [];
    
    const labels = history.map(entry => 
        entry.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    );
    
    const prices = history.map(entry => entry.price);
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Price Trend',
                data: prices,
                borderColor: '#2e7d32',
                backgroundColor: 'rgba(46, 125, 50, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const index = context.dataIndex;
                            const change = history[index].change;
                            return [
                                `Price: ₹${context.parsed.y}`,
                                `Hourly Change: ${change.hour >= 0 ? '+' : ''}${change.hour}%`,
                                `Daily Change: ${change.day >= 0 ? '+' : ''}${change.day}%`
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return '₹' + value;
                        }
                    }
                }
            }
        }
    });
}

// Update market statistics with more detailed information
function updateMarketStats() {
    const totalCrops = document.getElementById('totalCrops');
    const avgPriceChange = document.getElementById('avgPriceChange');
    const mostTraded = document.getElementById('mostTraded');
    const marketVolume = document.getElementById('marketVolume');

    if (marketData.length > 0) {
        totalCrops.textContent = marketData.length;
        
        const avgHourlyChange = marketData.reduce((sum, item) => sum + item.change.hour, 0) / marketData.length;
        avgPriceChange.textContent = `${avgHourlyChange.toFixed(2)}%`;
        avgPriceChange.className = avgHourlyChange >= 0 ? 'positive' : 'negative';

        // Find most traded crop based on trading volume
        const mostTradedCrop = marketData.reduce((max, item) => 
            item.tradingVolume > (max.tradingVolume || 0) ? item : max
        );
        mostTraded.textContent = `${mostTradedCrop.crop} (${mostTradedCrop.tradingVolume}M)`;

        // Calculate total market volume
        const totalVolume = marketData.reduce((sum, item) => sum + item.tradingVolume, 0);
        marketVolume.textContent = `${totalVolume}M`;
    }
}

// Display market data with enhanced real-time features
function displayMarketData(data) {
    const marketGrid = document.getElementById('marketGrid');
    
    if (data.length === 0) {
        marketGrid.innerHTML = `
            <div class="market-card">
                <h3 data-translate>No Data Available</h3>
                <p data-translate>No market data found for the selected filters.</p>
            </div>
        `;
        return;
    }

    marketGrid.innerHTML = data.map(item => `
        <div class="market-card">
            <h3>
                <span>${item.crop} ${item.variety ? `(${item.variety})` : ''}</span>
                <span class="price-change ${item.change.hour >= 0 ? 'positive' : 'negative'}">
                    <i class="fas fa-${item.change.hour >= 0 ? 'arrow-up' : 'arrow-down'}"></i>
                    ${Math.abs(item.change.hour)}%
                </span>
            </h3>
            <div class="price-info">
                <span class="current-price">₹${item.price}/${item.unit}</span>
                <div class="price-range">
                    <span>₹${item.minPrice} - ₹${item.maxPrice}</span>
                </div>
            </div>
            <div class="change-info">
                <span class="change-item ${item.change.day >= 0 ? 'positive' : 'negative'}">
                    <i class="fas fa-${item.change.day >= 0 ? 'arrow-up' : 'arrow-down'}"></i>
                    ${Math.abs(item.change.day)}% (24h)
                </span>
                <span class="change-item ${item.change.week >= 0 ? 'positive' : 'negative'}">
                    <i class="fas fa-${item.change.week >= 0 ? 'arrow-up' : 'arrow-down'}"></i>
                    ${Math.abs(item.change.week)}% (7d)
                </span>
            </div>
            <div class="chart-container">
                <canvas id="chart-${item.crop.replace(/\s+/g, '-')}"></canvas>
            </div>
            <div class="market-details">
                <p>
                    <strong data-translate>State:</strong>
                    <span>${item.state}</span>
                </p>
                <p>
                    <strong data-translate>Market:</strong>
                    <span>${item.market}</span>
                </p>
                <p>
                    <strong data-translate>Season:</strong>
                    <span>${item.season}</span>
                </p>
                <p>
                    <strong data-translate>Quality:</strong>
                    <span>${item.quality}</span>
                </p>
                <p>
                    <strong data-translate>Volume:</strong>
                    <span>${item.volume}</span>
                </p>
                <p>
                    <strong data-translate>Demand:</strong>
                    <span>${item.demand}</span>
                </p>
                <p>
                    <strong data-translate>Trading Volume:</strong>
                    <span>${item.tradingVolume}M</span>
                </p>
                <p>
                    <strong data-translate>Sentiment:</strong>
                    <span class="sentiment ${item.sentiment.toLowerCase()}">${item.sentiment}</span>
                </p>
                <p>
                    <strong data-translate>Last Updated:</strong>
                    <span>${new Date(item.lastUpdated).toLocaleString()}</span>
                </p>
            </div>
        </div>
    `).join('');

    // Create charts for each crop using real historical data
    data.forEach(item => {
        const canvasId = `chart-${item.crop.replace(/\s+/g, '-')}`;
        createPriceChart(canvasId, item.crop);
    });
}

// Populate state filter
function populateStateFilter() {
    const stateFilter = document.getElementById('stateFilter');
    indianStates.forEach(state => {
        const option = document.createElement('option');
        option.value = state;
        option.textContent = state;
        stateFilter.appendChild(option);
    });
}

// Populate crop filter
function populateCropFilter() {
    const cropFilter = document.getElementById('cropFilter');
    const uniqueCrops = [...new Set(marketData.map(item => item.crop))];
    
    uniqueCrops.forEach(crop => {
        const option = document.createElement('option');
        option.value = crop;
        option.textContent = crop;
        cropFilter.appendChild(option);
    });
}

// Update price ticker
function updatePriceTicker(data) {
    const tickerContent = document.getElementById('priceTicker');
    tickerContent.innerHTML = '';
    
    data.forEach(item => {
        const tickerItem = document.createElement('div');
        tickerItem.className = 'ticker-item';
        tickerItem.innerHTML = `
            <span>${item.crop}</span>
            <span class="${item.change.hour >= 0 ? 'positive' : 'negative'}">
                ₹${item.price} (${item.change.hour >= 0 ? '+' : ''}${Math.abs(item.change.hour)}%)
            </span>
        `;
        tickerContent.appendChild(tickerItem);
    });
}

// Update top gainers and losers
function updateTrends(data) {
    const sortedData = [...data].sort((a, b) => b.change.hour - a.change.hour);
    const topGainers = sortedData.slice(0, 5);
    const topLosers = sortedData.slice(-5).reverse();

    const gainersHtml = topGainers.map(item => `
        <div class="trend-item">
            <span>${item.crop}</span>
            <span class="positive">+${Math.abs(item.change.hour)}%</span>
        </div>
    `).join('');

    const losersHtml = topLosers.map(item => `
        <div class="trend-item">
            <span>${item.crop}</span>
            <span class="negative">${Math.abs(item.change.hour)}%</span>
        </div>
    `).join('');

    document.getElementById('topGainers').innerHTML = gainersHtml;
    document.getElementById('topLosers').innerHTML = losersHtml;
}

// Filter and sort market data
function filterMarketData() {
    const stateFilter = document.getElementById('stateFilter').value;
    const cropFilter = document.getElementById('cropFilter').value;
    const sortFilter = document.getElementById('sortFilter').value;

    let filteredData = [...marketData];

    if (stateFilter !== 'all') {
        filteredData = filteredData.filter(item => item.state === stateFilter);
    }

    if (cropFilter !== 'all') {
        filteredData = filteredData.filter(item => item.crop === cropFilter);
    }

    // Sort data
    switch (sortFilter) {
        case 'price':
            filteredData.sort((a, b) => b.price - a.price);
            break;
        case 'price_asc':
            filteredData.sort((a, b) => a.price - b.price);
            break;
        case 'change':
            filteredData.sort((a, b) => b.change.hour - a.change.hour);
            break;
        case 'name':
            filteredData.sort((a, b) => a.crop.localeCompare(b.crop));
            break;
    }

    displayMarketData(filteredData);
}

// Refresh market data
async function refreshMarketData() {
    const refreshButton = document.querySelector('.refresh-button');
    refreshButton.style.transform = 'rotate(180deg)';
    
    try {
        marketData = await fetchMarketData();
        if (validateMarketData(marketData)) {
            updatePriceTicker(marketData);
            updateMarketStats();
            updateTrends(marketData);
            displayMarketData(marketData);
        }
    } catch (error) {
        console.error('Error refreshing market data:', error);
    }
    
    setTimeout(() => {
        refreshButton.style.transform = 'rotate(0)';
    }, 1000);
}

// Initialize the market page
async function init() {
    try {
        marketData = await fetchMarketData();
        
        if (validateMarketData(marketData)) {
            updatePriceTicker(marketData);
            populateStateFilter();
            populateCropFilter();
            updateMarketStats();
            updateTrends(marketData);
            displayMarketData(marketData);

            // Update data every 5 minutes
            setInterval(refreshMarketData, 300000);
        } else {
            throw new Error('Invalid market data received');
        }
    } catch (error) {
        console.error('Error initializing market page:', error);
        document.getElementById('marketGrid').innerHTML = `
            <div class="market-card">
                <h3 data-translate>Error Loading Data</h3>
                <p data-translate>Unable to fetch market data. Please try again later.</p>
            </div>
        `;
    }
}

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', init);

// Add data validation function
function validateMarketData(data) {
    if (!Array.isArray(data)) return false;
    
    const requiredFields = [
        'crop', 'state', 'price', 'unit', 'change',
        'market', 'lastUpdated'
    ];
    
    return data.every(item => {
        return requiredFields.every(field => field in item) &&
               typeof item.price === 'number' &&
               typeof item.change === 'object' &&
               typeof item.lastUpdated === 'string';
    });
}

// Local fallback market data with enhanced information
function getLocalMarketData() {
    return [
        {
            crop: 'Rice',
            variety: 'Basmati',
            state: 'Punjab',
            price: 2500,
            unit: 'Quintal',
            change: {
                hour: 0.5,
                day: 0.5,
                week: 0.5
            },
            market: 'Amritsar',
            lastUpdated: new Date().toISOString(),
            season: 'Kharif',
            quality: 'Grade A',
            minPrice: 2300,
            maxPrice: 2700,
            volume: 'High',
            demand: 'Strong',
            tradingVolume: 3,
            sentiment: 'Positive'
        },
        {
            crop: 'Wheat',
            variety: 'Sharbati',
            state: 'Uttar Pradesh',
            price: 2200,
            unit: 'Quintal',
            change: {
                hour: -0.2,
                day: -0.2,
                week: -0.2
            },
            market: 'Kanpur',
            lastUpdated: new Date().toISOString(),
            season: 'Rabi',
            quality: 'Grade A',
            minPrice: 2100,
            maxPrice: 2300,
            volume: 'Medium',
            demand: 'Moderate',
            tradingVolume: 2,
            sentiment: 'Neutral'
        },
        {
            crop: 'Cotton',
            variety: 'BT Cotton',
            state: 'Gujarat',
            price: 6500,
            unit: 'Quintal',
            change: {
                hour: 0.8,
                day: 0.8,
                week: 0.8
            },
            market: 'Ahmedabad',
            lastUpdated: new Date().toISOString(),
            season: 'Kharif',
            quality: 'Medium Staple',
            minPrice: 6200,
            maxPrice: 6800,
            volume: 'High',
            demand: 'Strong',
            tradingVolume: 3,
            sentiment: 'Positive'
        },
        {
            crop: 'Sugarcane',
            variety: 'Co 86032',
            state: 'Maharashtra',
            price: 320,
            unit: 'Quintal',
            change: {
                hour: 0.1,
                day: 0.1,
                week: 0.1
            },
            market: 'Pune',
            lastUpdated: new Date().toISOString(),
            season: 'Annual',
            quality: 'Good Recovery',
            minPrice: 310,
            maxPrice: 330,
            volume: 'Very High',
            demand: 'Strong',
            tradingVolume: 2,
            sentiment: 'Positive'
        },
        {
            crop: 'Maize',
            variety: 'Hybrid',
            state: 'Karnataka',
            price: 1800,
            unit: 'Quintal',
            change: {
                hour: -0.1,
                day: -0.1,
                week: -0.1
            },
            market: 'Bangalore',
            lastUpdated: new Date().toISOString(),
            season: 'Kharif',
            quality: 'Grade A',
            minPrice: 1750,
            maxPrice: 1850,
            volume: 'Medium',
            demand: 'Moderate',
            tradingVolume: 2,
            sentiment: 'Neutral'
        },
        {
            crop: 'Soybean',
            variety: 'JS 335',
            state: 'Madhya Pradesh',
            price: 4200,
            unit: 'Quintal',
            change: {
                hour: 0.5,
                day: 0.5,
                week: 0.5
            },
            market: 'Indore',
            lastUpdated: new Date().toISOString(),
            season: 'Kharif',
            quality: 'Grade A',
            minPrice: 4100,
            maxPrice: 4300,
            volume: 'High',
            demand: 'Strong',
            tradingVolume: 3,
            sentiment: 'Positive'
        },
        {
            crop: 'Groundnut',
            variety: 'TMV 2',
            state: 'Andhra Pradesh',
            price: 5500,
            unit: 'Quintal',
            change: {
                hour: 0.5,
                day: 0.5,
                week: 0.5
            },
            market: 'Guntur',
            lastUpdated: new Date().toISOString(),
            season: 'Kharif',
            quality: 'Bold',
            minPrice: 5400,
            maxPrice: 5600,
            volume: 'Medium',
            demand: 'Moderate',
            tradingVolume: 2,
            sentiment: 'Neutral'
        },
        {
            crop: 'Turmeric',
            variety: 'Salem',
            state: 'Tamil Nadu',
            price: 8500,
            unit: 'Quintal',
            change: {
                hour: 0.5,
                day: 0.5,
                week: 0.5
            },
            market: 'Erode',
            lastUpdated: new Date().toISOString(),
            season: 'Annual',
            quality: 'Finger',
            minPrice: 8300,
            maxPrice: 8700,
            volume: 'Medium',
            demand: 'Strong',
            tradingVolume: 2,
            sentiment: 'Positive'
        }
    ];
} 