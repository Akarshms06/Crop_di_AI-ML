// Mock disease database
const diseaseDatabase = [
    {
        id: 1,
        name: "Leaf Rust",
        crop: "wheat",
        image: "https://via.placeholder.com/300x200?text=Leaf+Rust",
        symptoms: [
            "Small, circular orange-brown pustules on leaves",
            "Pustules may merge to form larger patches",
            "Leaves may turn yellow and die prematurely",
            "Reduced grain size and quality"
        ],
        causes: [
            "Fungal pathogen Puccinia triticina",
            "High humidity and moderate temperatures",
            "Poor air circulation in dense crops"
        ],
        treatments: {
            organic: [
                "Remove and destroy infected leaves",
                "Apply neem oil spray every 7-10 days",
                "Improve air circulation around plants",
                "Use resistant wheat varieties"
            ],
            chemical: [
                "Apply fungicide containing chlorothalonil",
                "Follow manufacturer's instructions for application",
                "Wear protective gear during application"
            ]
        },
        prevention: [
            "Plant resistant varieties",
            "Practice crop rotation",
            "Maintain proper plant spacing",
            "Monitor weather conditions"
        ]
    },
    {
        id: 2,
        name: "Bacterial Blight",
        crop: "rice",
        image: "https://via.placeholder.com/300x200?text=Bacterial+Blight",
        symptoms: [
            "Water-soaked lesions on leaves",
            "Yellowing and wilting of leaves",
            "Lesions may turn brown and dry",
            "Reduced grain yield"
        ],
        causes: [
            "Bacterium Xanthomonas oryzae",
            "High humidity and warm temperatures",
            "Infected seeds or plant debris"
        ],
        treatments: {
            organic: [
                "Remove infected plants immediately",
                "Use copper-based sprays",
                "Practice crop rotation",
                "Maintain proper water management"
            ],
            chemical: [
                "Apply copper-based bactericides",
                "Use streptomycin sulfate",
                "Follow strict application schedule"
            ]
        },
        prevention: [
            "Use disease-free seeds",
            "Avoid overhead irrigation",
            "Maintain proper plant spacing",
            "Clean farm equipment regularly"
        ]
    },
    {
        id: 3,
        name: "Powdery Mildew",
        crop: "vegetables",
        image: "https://via.placeholder.com/300x200?text=Powdery+Mildew",
        symptoms: [
            "White powdery spots on leaves",
            "Leaves may curl and distort",
            "Reduced plant growth",
            "Premature leaf drop"
        ],
        causes: [
            "Fungal pathogens in the Erysiphales order",
            "High humidity with moderate temperatures",
            "Poor air circulation"
        ],
        treatments: {
            organic: [
                "Spray with baking soda solution",
                "Remove affected plant parts",
                "Ensure proper spacing between plants",
                "Use resistant varieties"
            ],
            chemical: [
                "Apply sulfur-based fungicide",
                "Use potassium bicarbonate spray",
                "Follow safety guidelines for application"
            ]
        },
        prevention: [
            "Plant resistant varieties",
            "Maintain proper plant spacing",
            "Avoid overhead watering",
            "Monitor weather conditions"
        ]
    }
];

// Mock disease database and API responses
const mockAPIResponses = {
    "tomato blight": `
        <h4>Tomato Blight</h4>
        <p>A serious disease affecting tomato plants.</p>
        
        <h4>Symptoms:</h4>
        <ul>
            <li>Dark brown spots on leaves</li>
            <li>Wilting of leaves and stems</li>
            <li>Fruit rot with dark, greasy spots</li>
            <li>White, fuzzy growth in humid conditions</li>
        </ul>

        <h4>Causes:</h4>
        <ul>
            <li>Phytophthora infestans fungus</li>
            <li>High humidity and cool temperatures</li>
            <li>Poor air circulation</li>
        </ul>

        <h4>Treatment:</h4>
        <ul>
            <li>Remove and destroy infected plants</li>
            <li>Apply copper-based fungicides</li>
            <li>Improve air circulation</li>
            <li>Water at the base of plants</li>
        </ul>
    `,
    "rice blast": `
        <h4>Rice Blast Disease</h4>
        <p>A devastating fungal disease affecting rice crops worldwide.</p>
        
        <h4>Symptoms:</h4>
        <ul>
            <li>Diamond-shaped lesions on leaves</li>
            <li>White to gray centers in spots</li>
            <li>Infected grains become empty</li>
            <li>Reduced yield quality</li>
        </ul>

        <h4>Causes:</h4>
        <ul>
            <li>Magnaporthe oryzae fungus</li>
            <li>High humidity (>90%)</li>
            <li>Temperatures between 24-28°C</li>
        </ul>

        <h4>Treatment:</h4>
        <ul>
            <li>Use resistant rice varieties</li>
            <li>Apply fungicides preventively</li>
            <li>Maintain proper water management</li>
            <li>Balance nitrogen fertilization</li>
        </ul>
    `,
    "wheat rust": `
        <h4>Wheat Rust Disease</h4>
        <p>A common fungal disease affecting wheat crops.</p>
        
        <h4>Symptoms:</h4>
        <ul>
            <li>Orange-brown pustules on leaves</li>
            <li>Reduced grain quality</li>
            <li>Stunted growth</li>
            <li>Yellow streaking</li>
        </ul>

        <h4>Causes:</h4>
        <ul>
            <li>Puccinia species fungi</li>
            <li>Warm, humid conditions</li>
            <li>Susceptible wheat varieties</li>
        </ul>

        <h4>Treatment:</h4>
        <ul>
            <li>Plant resistant varieties</li>
            <li>Apply fungicides early</li>
            <li>Monitor crops regularly</li>
            <li>Practice crop rotation</li>
        </ul>
    `
};

// DOM Elements
const searchInput = document.getElementById('searchInput');
const diseaseGrid = document.getElementById('diseaseGrid');
const filterButtons = document.querySelectorAll('.filter-btn');

// Current filter state
let currentFilter = 'all';

// Create AI result card
function createAIResultCard(content) {
    return `
        <div class="disease-card">
            <div class="disease-content">
                <div class="chat-response">
                    ${marked.parse(content)}
                </div>
            </div>
        </div>
    `;
}

// Enhanced search using OpenRouter API
async function enhancedSearch(query) {
    try {
        // Show loading state
        diseaseGrid.innerHTML = '<div class="disease-card"><div class="disease-content"><h3>Searching...</h3><p>Please wait while we fetch results.</p></div></div>';

        // First, search in the local database
        const localResults = diseaseDatabase.filter(disease => {
            const diseaseName = disease.name.toLowerCase();
            const diseaseCrop = disease.crop.toLowerCase();
            const diseaseSymptoms = disease.symptoms.join(' ').toLowerCase();
            const diseaseCauses = disease.causes.join(' ').toLowerCase();
            
            return diseaseName.includes(query.toLowerCase()) ||
                   diseaseCrop.includes(query.toLowerCase()) ||
                   diseaseSymptoms.includes(query.toLowerCase()) ||
                   diseaseCauses.includes(query.toLowerCase());
        });

        if (localResults.length > 0) {
            return localResults.map(disease => createDiseaseCard(disease)).join('');
        }

        // If no local results, try OpenRouter API with the new model and API key
        let contentArr = [
          {
            "type": "text",
            "text": `You are a crop disease expert. Please provide information about: ${query}. Include symptoms, causes, and treatment options if available.`
          }
        ];
        // If the query looks like an image URL, add it as an image input
        if (query.startsWith('http://') || query.startsWith('https://')) {
          contentArr.push({
            "type": "image_url",
            "image_url": {
              "url": query
            }
          });
        }
        const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": "Bearer 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",
                "HTTP-Referer": window.location.origin,
                "X-Title": "Crop Doctor",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "model": "google/gemini-2.0-flash-exp:free",
                "messages": [
                  {
                    "role": "user",
                    "content": contentArr
                  }
                ]
            })
        });

        const data = await response.json();
        console.log('OpenRouter response:', JSON.stringify(data, null, 2));

        let markdownText = 'No response received.';
        if (data.choices && data.choices[0]?.message?.content) {
            markdownText = data.choices[0].message.content;
        } else if (data.error && data.error.message) {
            if (data.error.message.includes('Rate limit exceeded')) {
                markdownText = `AI search is temporarily unavailable due to usage limits. Please try again later or add credits to your OpenRouter account.`;
            } else {
                markdownText = `Error from API: ${data.error.message}`;
            }
        } else {
            markdownText = `Unexpected API response: <pre>${JSON.stringify(data, null, 2)}</pre>`;
        }

        return createAIResultCard(markdownText);
    } catch (error) {
        console.error('Error in search:', error);
        return createAIResultCard(`
            <h4>Error</h4>
            <p>Sorry, we encountered an error while searching. Please try again later.</p>
        `);
    }
}

// Filter diseases
async function filterDiseases() {
    let filteredDiseases = diseaseDatabase;
    
    if (currentFilter !== 'all') {
        filteredDiseases = filteredDiseases.filter(disease => disease.crop === currentFilter);
    }

    if (filteredDiseases.length === 0) {
        diseaseGrid.innerHTML = '<div class="disease-card"><div class="disease-content"><h3>No Results Found</h3><p>Please try a different filter.</p></div></div>';
    } else {
        diseaseGrid.innerHTML = filteredDiseases.map(disease => createDiseaseCard(disease)).join('');
    }
}

// Create disease card
function createDiseaseCard(disease) {
    return `
        <div class="disease-card">
            <img src="${disease.image}" alt="${disease.name}" class="disease-image">
            <div class="disease-content">
                <h3>${disease.name}</h3>
                <div class="disease-tags">
                    <span class="disease-tag">${disease.crop}</span>
                </div>
                <div class="disease-symptoms">
                    <h4>Symptoms</h4>
                    <ul>
                        ${disease.symptoms.map(symptom => `<li>${symptom}</li>`).join('')}
                    </ul>
                </div>
                <button class="analyze-btn" onclick="viewDiseaseDetails(${disease.id})">
                    View Details
                </button>
            </div>
        </div>
    `;
}

// View disease details
function viewDiseaseDetails(diseaseId) {
    const disease = diseaseDatabase.find(d => d.id === diseaseId);
    if (disease) {
        localStorage.setItem('selectedDisease', JSON.stringify(disease));
        window.location.href = 'result.html';
    }
}

// Handle filter button clicks
filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        currentFilter = button.dataset.crop;
        searchInput.value = ''; // Clear search when filter is changed
        filterDiseases();
    });
});

// Handle search input
searchInput.addEventListener('keyup', async (e) => {
    if (e.key === 'Enter') {
        await searchDiseases();
    }
});

// Search diseases
async function searchDiseases() {
    const searchTerm = searchInput.value.trim();
    if (!searchTerm) {
        // If search is empty, show all diseases
        currentFilter = 'all';
        filterButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.crop === 'all') {
                btn.classList.add('active');
            }
        });
        await filterDiseases();
        return;
    }

    try {
        const results = await enhancedSearch(searchTerm);
        diseaseGrid.innerHTML = results;
    } catch (error) {
        console.error('Error in search:', error);
        diseaseGrid.innerHTML = createAIResultCard(`
            <h4>Error</h4>
            <p>Sorry, we encountered an error while searching. Please try again later.</p>
        `);
    }
}

// Initialize the page
async function init() {
    await filterDiseases();
}

// Run initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', init); 
